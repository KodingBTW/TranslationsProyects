Titanic (C).nes
Traducido por koda 2024

------------------------------------------------------------------------------------------
INDICE
------------------------------------------------------------------------------------------

1. INSTRUCCIONES
2. VERSIONES
3. ERRORES CONOCIDOS
4. INFORMACIÓN ADICIONAL
5. CONTACTO

-------------------------------------------------------------------------------------------
1. INSTRUCCIONES
-------------------------------------------------------------------------------------------

Aplicar a la ROM Titanic (C).nes

Datos de la Rom:

Database match: not found
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 6C79B88169DCCD0D8F84A108FF0782E505E02277
File CRC32: E56D8DF2
ROM SHA-1: 53160D98B286084D71E25C70337D7F0129DED1EB
ROM CRC32: 85B3488B

Utilizen "Lunar IPS" o "Floating IPS"
Pueden descargarlo de acá:
https://www.romhacking.net/utilities/240/

-------------------------------------------------------------------------------------------
2. VERSIONES
-------------------------------------------------------------------------------------------

versión 1.0 (23/03/2024):

- Traducido completamente al español.
- Agregadas minúsculas y simbolos del español.
- Editadas las pantallas de "GAME OVER" y "THE END".

-------------------------------------------------------------------------------------------
3. ERRORES CONOCIDOS
-------------------------------------------------------------------------------------------

Ninguno que yo sepa, informar de alguno.

-------------------------------------------------------------------------------------------
4. INFORMACIÓN ADICIONAL

-------------------------------------------------------------------------------------------

Para la modificación de las pantallas de GAME OVER y THE END se utilizó el software gratuito
NEXXT 1.0.3, agradecimientos al creador del software.

offsets:

27AD0   THE END (16X16)
1FD79 -> 1FE27  THE END (8X8)


-------------------------------------------------------------------------------------------
5. CONTACTO
-------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda
Cualquier error enviar un mensaje a mi correo rodrigo.23luis@gmail.com