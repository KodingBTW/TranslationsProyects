Yoshi's Cookie (USA).nes
Traducido por koda 2024

------------------------------------------------------------------------------------------
INDICE
------------------------------------------------------------------------------------------

1. INSTRUCCIONES
2. VERSIONES
3. ERRORES CONOCIDOS
4. CONTACTO

-------------------------------------------------------------------------------------------
1. INSTRUCCIONES
-------------------------------------------------------------------------------------------

Este parche debe ser aplicado a la versión americana o europea.

HASH americano:

Database match: Yoshi's Cookie (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: F766507ACCC0976202C0124D991DDAC182CD1AA8
File CRC32: 1600AC5B
ROM SHA-1: 44AAE1649A4AD3AE73D5F24962590C2B7C0314EA
ROM CRC32: 52B58732

HASH Europeo:

Database match: Yoshi's Cookie (Europe)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: E4CF32734DD7D69E5D42DF54C49D49E51E1A7314
File CRC32: CEEC21D4
ROM SHA-1: 45442193F35F627959DFCC2C35B03F762492A35D
ROM CRC32: E37A39AB

Utilizen "Lunar IPS" o "Floating IPS"
Pueden descargarlo de aquí:
https://www.romhacking.net/utilities/240/

-------------------------------------------------------------------------------------------
2. VERSIONES
-------------------------------------------------------------------------------------------

versión 1.0 (22/10/2024):
- Traducido completamente.
- agregados símbolos especiales del español.
- Editados algunos punteros.

-------------------------------------------------------------------------------------------
3. ERRORES CONOCIDOS
-------------------------------------------------------------------------------------------

- En ambas versiones se crea una linea de gráficos basura durante la intro a un nivel, se arreglará en otra ocasión.

-------------------------------------------------------------------------------------------
4. CONTACTO
-------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda. Visita https://traduccioneskoda.blogspot.com para más traducciones.

Correo contacto: traduccioneskoda@gmail.com