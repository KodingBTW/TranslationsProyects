T&C Surf Desing - Wood & Water Rage (USA)
Traducido por koda 2024

------------------------------------------------------------------------------------------
INDICE
------------------------------------------------------------------------------------------

1. INTRODUCCIÓN
2. INSTRUCCIONES
3. VERSIONES
4. MOTIVACIÓN
5. AGRADECIMIENTOS
6. CONTACTO
------------------------------------------------------------------------------------------
1. INTRODUCCIÓN
------------------------------------------------------------------------------------------
Esta es un traducción original, 

A nivel técnico no es un juego dificil de traducir, puesto que no contiene mucho texto,
pero tiene muy pocas fuentes(gráficos) lo cual supone un reto a la hora de quitar y añadir gráficos.
El juego por defecto no viene bien optimizado, posee muchos gráficos duplicados, los
cuales he aprovechado para gregar fuentes nuevas y por supuesto he aprovechado de optimizar para
generar más espacio libre. Se han modificado algunas fuentes originales que visualmente eran 
pobres y que dificultaban la lectura, además de no mantener una buena estetica.

Por el momento tuve que modificar un color en la pantalla inicial, pero esto se arreglará
en el futuro.

-------------------------------------------------------------------------------------------
2. INSTRUCCIONES
-------------------------------------------------------------------------------------------

Este parche debe ser aplicado a la versión americana.

La ROM original es:

Database match: Town & Country Surf Designs - Wood & Water Rage (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 7114BC8B0AAD3094E59CCEDBA2845C1C032B15CC
File CRC32: 9C94ED32
ROM SHA-1: 5AFD9664716116B498354B4048D743D98540BF79
ROM CRC32: D3BFF72E

Utilizen "Lunar IPS" o "Floating IPS"
Pueden descargarlo de acá:
https://www.romhacking.net/utilities/240/

-------------------------------------------------------------------------------------------
3. VERSIONES
-------------------------------------------------------------------------------------------

version 1.0 (30/01/2024):

- Traduccion completa y nuevos gráficos.
- Mejora espacio de los gráficos.


-------------------------------------------------------------------------------------------
4. MOTIVACIÓN
-------------------------------------------------------------------------------------------

El primer romhacking que hago, más que nada un desafío personal, ya que siempre quize hacer
traducciones de videojuegos.
-------------------------------------------------------------------------------------------
5. AGRADECIMIENTOS
-------------------------------------------------------------------------------------------

A la comunidad de romhacking por sus tutoriales y especificamente DaRKWiZaRDX.

-------------------------------------------------------------------------------------------
6. CONTACTO
-------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda
Cualquier error enviar un mensaje a mi correo rodrigo.23luis@gmail.com