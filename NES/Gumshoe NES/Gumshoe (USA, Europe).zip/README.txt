Gumshoe (USA, Europe).nes
Traducido por koda 2024

------------------------------------------------------------------------------------------
INDICE
------------------------------------------------------------------------------------------

1. INSTRUCCIONES
2. VERSIONES
3. ERRORES CONOCIDOS
4. CONTACTO

-------------------------------------------------------------------------------------------
1. INSTRUCCIONES
-------------------------------------------------------------------------------------------

Este parche debe ser aplicado a la versión americana u europea.

La ROM es:

Database match: Gumshoe (USA, Europe)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: D2C9308FDCE6AC6A6ED4819FF51FF3985CED5C68
File CRC32: AAB00873
ROM SHA-1: F3250A728E7A1C21E011F187B90EE553C2D7FA7C
ROM CRC32: BEB8AB01

Utilizen "Lunar IPS" o "Floating IPS"
Pueden descargarlo de acá:
https://www.romhacking.net/utilities/240/

-------------------------------------------------------------------------------------------
2. VERSIONES
-------------------------------------------------------------------------------------------

version 1.0 (15/02/2024):

- Traducción completa al español.
- Editados algunos punteros.
- Agregadas algunas letras del español, tíldes y "ñ".

-------------------------------------------------------------------------------------------
3. ERRORES CONOCIDOS
-------------------------------------------------------------------------------------------

- Ninguno que yo sepa, reportar alguno.

-------------------------------------------------------------------------------------------
4. CONTACTO
-------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda
Cualquier error enviar un mensaje a mi correo rodrigo.23luis@gmail.com