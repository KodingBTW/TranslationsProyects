Goof Troop (USA).sfc
Traducido por koda 2024

-------------------------------------------------------------------------------------------
ÍNDICE
-------------------------------------------------------------------------------------------

1. INSTRUCCIONES
2. VERSIONES
3. ERRORES CONOCIDOS
4. INFORMACIÓN ADICIONAL
5. AGRAECIMIENTOS
6. CONTACTO

--------------------------------------------------------------------------------------------
1. INSTRUCCIONES
--------------------------------------------------------------------------------------------

Este parche debe ser aplicado a la versión americana.

INFORMACION DE LA ROM:

Database match: Goof Troop (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: B38560D091801DB5E833D17393FE1DF1398909B6
File/ROM CRC32: 4AAFA462

Utilizen "Lunar IPS".
Pueden descargarlo de aquí:
https://www.romhacking.net/utilities/240/

*No funciona en la versión europea.
--------------------------------------------------------------------------------------------
2. VERSIONES
--------------------------------------------------------------------------------------------

Versión 1.0 (24/10/2024):

- Menú principal traducido (Solo texto).
- Menú de opciones traducido.
- Pantalla de códigos traducido.
- Pantalla de Selección de jugadores traducida.
- Pantalla de Selección de nivel traducida.
- Cutscenes y cuadros de texto traducidos.
- Gráficos con textos traducidos.
- Créditos Traducidos.

Versión 1.1 (24/11/2024):

- Repasado el script principal.

--------------------------------------------------------------------------------------------
3. ERRORES CONOCIDOS
--------------------------------------------------------------------------------------------

- Ninguno que yo sepa, si se encuentra alguno, mandar un mensaje por correo ver en contacto.

--------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------
4. INFORMACIÓN ADICIONAL

- Por el momento lo único que queda sin traducir es la imagen del menú principal,
si alguien logra hacer el e insertar puede mandarme un correo y así se puede actualizar.
dejo el offset 0x4ED44 --> 0x4F054

- https://github.com/KodingBTW/gooftrooptranslationtool

--------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------
5. AGRADECIMIENTOS

- A zarby89 por la herramienta que ayuda a descomprimir y comprimir los gráficos. Más
información Aquí https://github.com/Zarby89/GoofTroopEditor

--------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------
6. CONTACTO
--------------------------------------------------------------------------------------------

Traducción hecha por rodrigo muñoz, alias koda. Visita https://traduccioneskoda.blogspot.com
para más traducciones.

Correo contacto: traduccioneskoda@gmail.com